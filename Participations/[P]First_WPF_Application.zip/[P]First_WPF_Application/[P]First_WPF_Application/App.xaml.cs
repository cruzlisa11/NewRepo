﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace _P_First_WPF_Application
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
    }

}
